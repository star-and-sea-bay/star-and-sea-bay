import serial
import serial.tools.list_ports
import tkinter as tk

################################通信字符串#########################################
row_number = 0
down_string = b'S\r\n'
up_string = b'W\r\n'
left_string = b'A\r\n'
right_string = b'D\r\n'
########################################################################


def open_serial():
    global ser
    global serial_is_open
    global port_number
    global row_number
    port_num = port_number.get()
    port = list(port_list[port_num])
    serialName = port[0]
    print(serialName)
    ser = serial.Serial(serialName, 9600, timeout=60)
    if ser.is_open:
        ser.close()
        ser.open()
    else:
        ser.open()
    tk.Label(window, text='The '+str(serialName)+' is opened')\
        .grid(row=row_number+1)
    row_number += 1
    serial_is_open = True


def UP_serial():
    global ser
    ser.write(up_string)


def DOWN_serial():
    global ser
    ser.write(down_string)


def LEFT_serial():
    global ser
    ser.write(left_string)


def RIGHT_serial():
    global ser
    ser.write(right_string)


def callback2(event):
    global serial_is_open
    if serial_is_open:
        if event.keysym == 'w' or event.keysym == 'W' or event.keysym == 'Up':
            UP_serial()
        elif event.keysym == 's' or event.keysym == 'S' or event.keysym == 'Down':
            DOWN_serial()
        elif event.keysym == 'a' or event.keysym == 'A' or event.keysym == 'Left':
            LEFT_serial()
        elif event.keysym == 'd' or event.keysym == 'D' or event.keysym == 'Right':
            RIGHT_serial()


################################界面设置######################################
window = tk.Tk()
port_number = tk.IntVar()
window.title('贪吃蛇')
window.geometry("500x300")
frame = tk.Frame(window)
frame.bind('<Key>', callback2)
frame.focus_set()
frame.grid()
####################################串口设置##########################
port_list = list(serial.tools.list_ports.comports())
ser = serial.Serial()
serial_is_open = False
if len(port_list) <= 0:
    tk.Message(window, text='Not find Serial port', width=100).grid()
else:
    tk.Label(window, text='检测到串口如下，请选择CH340的端口:').grid(
        row=0, column=0, stick=tk.W)
    for i in range(0, len(port_list)):
        tk.Radiobutton(window, text=str(
            port_list[i]), variable=port_number, value=i, command=open_serial).grid(row=row_number+1, column=0, stick=tk.W)
        row_number += 1
############################################################################
tk.Button(window, text='上', command=UP_serial).grid(row=row_number+2)
tk.Button(window, text='下', command=DOWN_serial).grid(row=row_number+4)
tk.Button(window, text='左', command=LEFT_serial).grid(row=row_number+3,stick=tk.W)
tk.Button(window, text='右', command=RIGHT_serial).grid(row=row_number+3,stick=tk.E)
window.mainloop()
